Name: {{ $name }} <br>
Email: {{ $email }} <br>
Telephone: {{ $telephone }} <br>
Website: {{ $website }} <br>
Details: {{ $details }}