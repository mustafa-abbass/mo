<footer class="content-info">

  <div class="container">

    <ul class="list-unstyled">
      <li>
        <a href="mailto:me@aaronjfrey.com" target="_blank" title="My Email">
          <i class="fal fa-envelope"></i>Email
        </a>
      </li>
      <li>
        <a href="//github.com/aaronfrey" target="_blank" title="My Github">
          <i class="fab fa-github-alt"></i>Github
        </a>
      </li>
      <li>
        <a href="//stackoverflow.com/users/3084110/aaron-frey" target="_blank" title="My Stack Overflow">
          <i class="fab fa-stack-overflow"></i>Stack Overflow
        </a>
      </li>  
      <li>
        <a href="//www.linkedin.com/in/aaronjfrey" target="_blank" title="My LinkedIn">
          <i class="fab fa-linkedin"></i>LinkedIn
        </a>
      </li>
      <li>
        <a href="//trello.com/aaronjfrey" target="_blank" title="My Trello">
          <i class="fab fa-trello"></i>Trello
        </a>
      </li>
      <li>
        <a href="//profiles.wordpress.org/aaronfrey" target="_blank" title="My Wordpress">
          <i class="fab fa-wordpress-simple"></i>Wordpress
        </a>
      </li>        
      <li>
        <a href="//www.facebook.com/aaronjfrey" target="_blank" title="My Facebook">
          <i class="fab fa-facebook-square"></i>Facebook
        </a>
      </li>
      <li>
        <a href="skype:aaron.j.frey" target="_blank" title="My Skype">
          <i class="fab fa-skype"></i>Skype
        </a>
      </li>
    </ul>

  </div>

</footer>