<header class="banner">

  <div class="container">

    <a class="brand" href="{{ url('/') }}">
      <img src="{{ asset('img/headshot-square.jpg') }}">
      <i class="fal fa-code"></i>
    </a>

    <div class="brand-text">

      <h2><a href="mailto:me@aaronjfrey.com" target="_blank">Aaron Frey</a></h2>
      <h3>Full Stack Developer</h3>

      <nav class="nav-primary">
        <ul class="nav">
          <li><a href="{{ url('plugins') }}">Plugins</a></li>
          <li><a href="{{ url('resume') }}">Resume</a></li>
        </ul>
      </nav>

    </div>

  </div>

</header>