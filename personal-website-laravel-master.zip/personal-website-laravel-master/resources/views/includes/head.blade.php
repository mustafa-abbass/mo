<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Aaron Frey - @yield('title')</title>
<link rel="stylesheet" href="{{ mix('/css/app.css') }}">

<!-- fontawesome -->
<script defer src="{{ asset('js/fontawesome/brands.js') }}"></script>
<script defer src="{{ asset('js/fontawesome/light.js') }}"></script>
<script defer src="{{ asset('js/fontawesome/fontawesome.js') }}"></script>